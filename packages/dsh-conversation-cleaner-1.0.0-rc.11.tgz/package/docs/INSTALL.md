# 安装、升级与卸载

当前包：`dsh-conversation-cleaner-1.0.0-rc.11.tgz`。验证范围：Windows、NEXT 2.0.20-next / Core 0.2.1-rc.3，以及官方 DSH Web 0.2.1-rc.3。

## NEXT

1. 插件 → 添加插件。
2. 输入 `https://github.com/sunyapeng-hub/dsh-conversation-cleaner`，或下载 tgz 后输入本地路径。
3. 安装、启用，然后重启 NEXT，避免旧 ESM 模块留在内存。
4. 悬停会话行，打开 `···`，选择「删除对话」。

`desktop` profile 只能由 Electron 管理，CLI 会拒绝修改。升级：在应用内卸载、返回列表、安装新版、启用并重启。卸载不清空隔离事务。

## 官方 DSH

```powershell
dsh plugin --profile web add "./dsh-conversation-cleaner-1.0.0-rc.11.tgz"
dsh --profile web
```

自选数据目录请在启动前设置 `DSH_HOME`，以实际 Host 报告的路径为准。默认配置即可，无需 `exclusiveDataRoot: true`。

## 使用边界

升级后正常重启一次。空闲且无待处理内容的本宿主目标在点击删除后自动关闭；预览、取消不关闭。启动前已加载的空闲会话可经原始生命周期关闭函数释放。运行中、维护中、待发送内容或其他进程占用仍拒绝。B 无产出、C 无产出且无附件时只处理选中会话；实际文件和附件清理仍需要完整创建证据和引用核对，依据不完整时保留这些资源。

rc.11 中，历史归属不完整或外部资源引用无法确认时，预览会明确改为「仅删除对话、文件和附件保留」，允许按清单删除；不会猜测未知文件的创建归属。目标会话本身无法读取、占用、索引冲突或操作范围超限仍会阻止删除。

共享根要求所有写入 Host 安装兼容插件。其他宿主改变索引后，落后的 Host 会要求重启，避免覆盖新索引。

删除成功后可直接恢复。关闭弹窗后，从会话菜单或「插件 → 本包详情 → 删除记录与恢复」选择记录，恢复、继续永久清理或清理旧终态残留。旧残留不会在升级时自动清理。

## 卸载与回退

NEXT：插件详情 → 卸载。官方 DSH：

```powershell
dsh plugin --profile web remove dsh-conversation-cleaner
```

菜单、弹窗和路由随生命周期卸载，隔离数据保留；重新安装兼容版本后仍可按 [恢复文档](RESTORE.md) 处理。

开发回退只使用最初的 `backups/DSH_Conversation_Cleaner_V1_original.zip`，不创建后续备份。

