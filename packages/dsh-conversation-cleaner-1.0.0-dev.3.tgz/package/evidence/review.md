# Independent review and fixes

One read-only reviewer was used via the requesting-code-review skill. No reviewer edits or extra backups were made.

| Finding | Resolution |
|---|---|
| Survivor cwd filter misses references | Inspect all surviving session identities |
| Stale survivor proof trusted | Validate current durable call IDs and unsupported dispatch types |
| grep/glob references incomplete | Treat them as unknown; canonicalize read paths |
| No global publication barrier | Block actual output deletion; B remains incomplete |
| Permanent intent prevents pre-purge recovery | Only PURGING/PERMANENT are irreversible; regression RED→GREEN |
| Dead process leaves directory lock | Owner PID and offline unlock, tested with a real child process |
| Missing original/staged files reported restored | Refuse RESTORE_FILE_MISSING, verify files |
| Cross-volume staging fails halfway | Preflight device IDs and block |
| Multi-host cached registry conflict | Default preview-only; exclusive deployment declaration required |
| Restore emits removal | Emit added summaries; live row restoration verified in real host |

Decisions:

- Node ESM and host-provided React/UI keep runtime dependencies at zero; no TypeScript contract compilation is claimed.
- User's no-checksum request overrides attachment digest/hash instructions. Use server-owned nonce-bound plans, filesystem identities and in-memory byte comparison.
- Workspace began empty and without a product Git repository. No worktree, commit, push or PR was needed.
- Deliver a dev package with truthful BLOCKED status. Full B/C/NEXT scope is unfinished and cannot be called V1.0 complete.

Remaining limitations: title fallback when the host gives no title, API-only restore instead of a dedicated dialog, and incomplete bilingual/theme/zoom/keyboard acceptance. These are not marked passed.
