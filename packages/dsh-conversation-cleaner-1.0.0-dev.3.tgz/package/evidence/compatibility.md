# Compatibility evidence — 2026-11-02

## Actual environment

- Node CLI/test runtime: 22.19.0.
- Installed NEXT: `2.0.20-next`, bundled official DSH: `0.2.1-rc.3`. Read from installed app.asar/package metadata and native run logs, not inferred from reference versions.
- Official CLI/Core rc.3 extracted read-only with its dependencies to `research/installed-next`. Original app binaries were not patched.
- Real Web profile: `web`; data root: `F:\Projects\PLUS Project\.test-data\dsh`. Runtime root confirmed by fixture output and restart/restore JSON.
- NEXT attempted root: `F:\Projects\PLUS Project\.test-data\next`. No page/Host generation available for testing; actual desktop profile is NOT_VERIFIED.
- The installed rc.3 package's exact source commit is not exposed in local metadata. It is unknown, not equated to current upstream HEAD.

## Fixed research revisions

| Repository | Exact revision | License |
|---|---|---|
| [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) | ce7073d51254c26cd63b22a60835b8f948deb447 | MIT |
| [anywhere-labs/dsh-desktop](https://github.com/anywhere-labs/dsh-desktop) | 6deca8ba89e3c86da7a5532e27cecfad5429c176 | MIT |
| [DDDMUC/dsh-delete-session](https://github.com/DDDMUC/dsh-delete-session) | 388b8369590c4ba9fdf5076c25d64141e744b5e3 | MIT |
| [fufu1437/dsh-delete-chat](https://github.com/fufu1437/dsh-delete-chat) | 4506abe695071ab974147a80b461d5a248a65e25 | MIT |
| [ljp888/dsh-session-delete-next](https://github.com/ljp888/dsh-session-delete-next) | 0b421068881cd59a080a9e5b82dd1d4bdf2e141a | MIT |

Revisions identify researched sources; no delivery checksums are generated.

## Owning contracts

Paths below are relative to `research/installed-next/node_modules/@deepseek-ai/`, installed rc.3 artifacts.

| Contract | Source | Use / constraint |
|---|---|---|
| Precise session path | `dsh-session-persistence-jsonl/lib/index.js:2450` | `locate(header).path` and actual instance `root` |
| Open read/write | same file, 2488 | Retain write handle until staging/registry verification finishes |
| Native cross-process lease | same file, 658–735 | Keep `session.lock` at original path/inode |
| Recovery lease | same file, 2976 | `acquireWriteLease(header)` for absent session; version-specific implementation method |
| Registry | `dsh-workspace/lib/index.js:103`, 148, 553, 568, 598 | attach/detach, pin/archive; no guessing index files |
| Auth | `dsh-client-connection/lib/index.js:737` | authenticated `connection.requestRejection(req)` plus explicit same-origin fence |
| Menu | `dsh-client-ui-workspace/lib/client.js:2345` | host-provided ID and displayTitle; public menu slot |
| Modal | `dsh-client-ui-primitives/lib/index.js:5118` | native modal keyboard/focus lifecycle |
| Refresh | upstream `packages/api/session-controller/src/types.ts:665` | `api-session/removed`; restore uses public controller summaries and `api-session/added` |
| Attachments | `dsh-attachment-local/lib/index.js:993` | immutable object root; no verified atomic reference/GC barrier |
| Shared registry | `dsh-storage-json/lib/index.js:162` | in-memory-authoritative unit rewrites; target session lock cannot coordinate other registry owners |

Upstream source snapshot corroborates architecture, not runtime compatibility of rc.5 or every NEXT version.

## Reference plugin assessment

Reviewed host/client entries, package/patch manifests, tests/scripts, READMEs and LICENSE files of the three reference repositories. No third-party plugin source file is redistributed.

- delete-session: useful public slot and lifecycle examples; environment-home fallback, short lease probes and best-effort cleanup do not establish this spec's full transaction.
- delete-chat: useful auth and reference exploration; permanent cleanup and best-effort warnings do not prove three-mode atomicity or output ownership.
- delete-next: useful locate/registry APIs; permanent file removal and best-effort index updates do not provide recoverable transactions.

## Remaining blockers

1. B lacks a global publication barrier against new/surviving references. Provenance checks alone are insufficient; actual output removal is blocked.
2. C lacks a barrier covering uploads, durable logs and persistent reference caches; actual attachment removal is blocked.
3. Shared registry snapshots may conflict across hosts. Default commit is disabled; explicit single-owner deployment is required. This is not a shared-root compatibility claim.
4. NEXT native run logs show startup and graceful shutdown. CDP returned zero page targets. `research/installed-next/lib/main.js:5640` shows a native data-directory transition dialog may precede page creation; attributing this attempt to that dialog remains an inference. Windows UI runtimes failed with sandbox/login error 1385, so no dialog was bypassed and no NEXT gate passed.
5. Cross-volume quarantine is unsupported and blocked before staging.

The original checksum-based release checker was not used to claim success. The no-checksum checker correctly reports BLOCKED.
