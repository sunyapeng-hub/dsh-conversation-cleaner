# 隔离恢复与中断处理

删除默认将精确文件移入实际数据根目录下的 `.conversation-cleaner/operations/<operationId>/`。这里是产品删除操作的恢复区，不是开发过程的重复备份。用户要求的初始项目备份只有 `backups/DSH_Conversation_Cleaner_V1_original.zip` 一份。

成功弹窗显示操作 ID。恢复不会覆盖原路径已有文件；出现路径占用、文件丢失或链接时拒绝。暂不提供恢复 UI，可在已登录 DSH 页面的浏览器开发者工具中调用同源 Host 接口：

```javascript
await fetch('/dsh-conversation-cleaner/v1/restore', {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ operationId: '替换为你的操作 ID', acknowledged: true })
}).then(response => response.json())
```

恢复会恢复日志、投影缓存和工作区归属，再广播宿主事件。真实 Web 恢复已验证；恢复 UI 及复杂归档排序恢复仍有验收缺口。初次调试的 dev.1 事务不具备 dev.2 完整恢复元数据，不作为可恢复成品事务。

## 进程中断后

1. 完全退出访问此数据目录的所有 DSH 与 NEXT。
2. 检查 `.conversation-cleaner/transaction.lock/owner.json`。如果记录的进程仍活着，不允许解除锁。
3. 仅对已死亡进程留下的锁，在项目中执行：

```powershell
node tools/offline-unlock.mjs '实际 DSH 数据根目录' --all-hosts-stopped
```

脚本会检查进程已退出，仅移除锁目录和 owner 文件，保留所有 journal 与隔离内容。它不会停止宿主。缺少/损坏 owner 信息时需人工检查，脚本不会强制解锁。

4. 用原来的独占 profile 启动宿主，通过 `operations` 接口查询未完成事务，然后按上面的 `restore` 调用恢复：

```javascript
await fetch('/dsh-conversation-cleaner/v1/operations', {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}'
}).then(response => response.json())
```

进入 `PURGING` 或 `PERMANENT` 的事务不能恢复。仅有永久删除意图、尚未开始清空隔离文件的中断事务允许恢复。永久删除需额外输入 `DELETE`；不会从隔离失败自动回退到永久删除。

本开发版本通过同卷原子 rename 隔离，不支持跨卷产出文件移动。不会使用系统回收站，不承诺云端、备份或其他设备副本被抹除。
