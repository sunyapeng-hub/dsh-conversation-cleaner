# 安装与当前状态

当前交付为 **1.0.0-dev.3 开发包**，不是双宿主三档全部验收通过的 V1.0。

- 已在官方 DSH CLI/Core `0.2.1-rc.3` 的真实 Web profile 安装同一 tgz；Edge 实际完成 A 档删除、多客户端刷新、重启及隔离恢复。
- B 档的文件归属追踪和预览已实现，但宿主缺少全局引用发布屏障，产出文件的实际删除被阻止。
- C 档缺少附件全局引用屏障，实际附件删除被阻止。
- 本机 NEXT 为 `2.0.20-next`、内置 DSH `0.2.1-rc.3`。隔离启动未进入可测试页面，未完成 desktop profile 安装和删除验收。
- 共享数据根目录尚未验证，不能开启实际删除。默认所有档可预览，提交需要独占数据目录条件。

## 官方 DSH

在你的 DSH CLI 环境执行（先核实 `dsh --version` 和实际数据目录）：

```powershell
dsh plugin --profile web add "F:\Projects\PLUS Project\release\dsh-conversation-cleaner-1.0.0-dev.3.tgz"
```

这里的命令格式已通过本机 CLI 的 `plugin --help` 和隔离安装验证。本机没有全局 `dsh` 命令，开发测试使用提取出的官方 CLI：

```powershell
$env:DSH_HOME = 'F:\Projects\PLUS Project\.test-data\dsh'
node 'F:\Projects\PLUS Project\research\installed-next\node_modules\@deepseek-ai\dsh\lib\bin.js' plugin --profile web add 'F:\Projects\PLUS Project\release\dsh-conversation-cleaner-1.0.0-dev.3.tgz'
```

安装后重启 profile，检查插件页和会话行 `···` 菜单的「删除对话」。所有删除都需要预览与风险确认。

开发包只支持**单宿主独占的数据目录**。确认其他 DSH/NEXT 都不访问该目录后，在该 profile 的 `cordis.patch.yml` 添加：

```yaml
- id: dsh-conversation-cleaner
  config:
    exclusiveDataRoot: true
```

此项是部署约束声明，不能协调未安装插件的其他进程。不要对原版/NEXT 共用的正式 `.dsh` 开启。无法保证独占时保持默认预览模式。

## DSH NEXT

下面是待实际验证的安装流程，不代表已经通过 NEXT 验收：先在 NEXT 设置中选独立测试数据目录，完全退出应用，在该目录对应的 CLI 环境执行：

```powershell
dsh plugin --profile desktop add "F:\Projects\PLUS Project\release\dsh-conversation-cleaner-1.0.0-dev.3.tgz"
```

随后正常启动 NEXT，检查其运行日志确认数据根目录、`desktop` profile 以及 Host/Client 加载状态。应用内选择的数据目录优先于环境变量，不能仅凭设置 `DSH_DESKTOP_NEXT_HOME` 就认定隔离生效。

## 卸载

```powershell
dsh plugin --profile web remove dsh-conversation-cleaner
# NEXT 在其实际数据根目录环境中使用 --profile desktop
```

这会移除 bundle。重启后菜单、弹窗和接口随 Cordis 生命周期卸载。隔离区不会自动清空；恢复应在卸载前完成，或重新安装相同开发版本后处理。

## 源码与测试

```powershell
npm ci --ignore-scripts
npm test
npm run build
```

运行时没有第三方依赖；Playwright 仅用于开发验证。`tests/web-e2e.mjs` 只适用于本项目 `.test-data` 夹具宿主，不得指向正式数据。
