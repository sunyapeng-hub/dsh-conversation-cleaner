# DSH Conversation Cleaner

**`1.0.0-dev.3` 开发包，整体验收状态 `BLOCKED`，不是双宿主三档全部完成的 V1.0。**

单个 Cordis bundle，使用宿主菜单、Modal、鉴权与持久化服务。三档弹窗、只读计划、确认、隔离、事务 journal、补偿、永久删除二次确认与恢复已实现。

- A「仅对话」：独占测试目录的官方 DSH/Core `0.2.1-rc.3` + Edge 已验证安装、含消息会话删除、非目标文件保留、多客户端刷新、重启及恢复。
- B「对话+产出」：有归属追踪与预览；缺少宿主全局文件引用屏障，实际产出删除被阻止。
- C「全部清理」：缺少附件全局引用屏障，实际附件删除被阻止。
- NEXT `2.0.20-next` / Core `0.2.1-rc.3`：已识别本机版本并尝试隔离启动，未完成 desktop profile 安装与删除验收。

默认允许预览，提交需要独占数据目录声明；共享 `.dsh` 不受支持。

安装包：`release/dsh-conversation-cleaner-1.0.0-dev.3.tgz`。

文档：[安装与卸载](docs/INSTALL.md)、[恢复](docs/RESTORE.md)、[发布说明](docs/RELEASE_NOTES.md)、[兼容性](evidence/compatibility.md)、[验收报告](evidence/acceptance-report.json)、[评审记录](evidence/review.md)。

开发：`npm ci --ignore-scripts`、`npm test`、`npm run build`。运行时无第三方依赖，React/UI 由宿主提供。

按用户要求先写 `AGENTS.md`，仅备份原始 ZIP 一次，不生成或验证校验和，未发布 npm 或远程仓库。`specification/` 保留原始需求；其中校验和要求由用户本轮指令覆盖。
